Version 1.2.0
+ Fix - Twitter section align center fix
+ Update - Documentation for Contact Form

Version 1.1.0
- Updated - mail sender ( validate email )